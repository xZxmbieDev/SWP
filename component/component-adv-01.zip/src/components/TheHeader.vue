<template>
  <header>
    <h1>More on Vue Components Slots</h1>
  </header>
</template>

// scoped styles betreffen nur die "lokale" Komponente sind also nicht global 

<style>
  header {
    width: 100%;
    height: 5rem;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #14005e;
  }

  header h1 {
    color: white;
    margin: 0;
  }
</style>